
Mask Wearing - v4 raw
==============================

This dataset was exported via roboflow.ai on September 25, 2020 at 9:52 AM GMT

It includes 149 images.
People are annotated in Tensorflow Object Detection format.

The following pre-processing was applied to each image:

No image augmentation techniques were applied.


